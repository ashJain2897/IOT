##############################################################################

Project Name:Thermometer(DS18B20) on Arduino and RaspberryPi
Project Date: 04/07/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

Raspberry Pi Connections:

VCC     5V
GND     GND
DATA    GPIO 4(board 7)

Arduino Conmections:

VCC    5V
GND    GND
DATA  Digital 2

###############################################################################
Full Information of Thermometer:

Steps for setup on Pi:

	open  /boot/config.txt	
	
	mention gpio pin 4

RaspberryPi Codes path:
path of temperature file:     /sys/bus/w1/devices/28*/w1_slave

Links:

Arduino:
	https://randomnerdtutorials.com/guide-for-ds18b20-temperature-sensor-with-arduino/
	https://create.arduino.cc/projecthub/TheGadgetBoy/ds18b20-digital-temperature-sensor-and-arduino-9cc806
Pi:
	http://www.circuitbasics.com/raspberry-pi-ds18b20-temperature-sensor-tutorial/
	https://www.youtube.com/watch?v=j7LLVkPpQ78