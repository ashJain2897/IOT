##############################################################################

Project Name:DHT22 on Arduino and RaspberryPi
Project Date: 02/07/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

Raspberry Pi Connections:


VCC		VCC
Data		GPIO4
GND		GND

Arduino Conmections:

VCC		VCC
Data		pin 7
pin 3		nc
GND		GND

###############################################################################
Full Information of DHT22

Arduino:

http://www.circuitbasics.com/how-to-set-up-the-dht11-humidity-sensor-on-an-arduino/
http://www.circuitbasics.com/arduino-thermistor-temperature-sensor-tutorial
http://www.ardumotive.com/how-to-use-dht-22-sensor-en.html

Pi:
Steps to install the libraries for DHT22

1. Enter below command to  download the library.
	git clone https://github.com/adafruit/Adafruit_Python_DHT.git

2. Then enter in to the installed directory using the below command
	cd Adafruit_Python_DHT

3. Then install the library using below command 
	sudo python setup.py install
