import Adafruit_DHT as dht
from time import sleep
while 1:
    humi,temo=dht.read_retry(dhtDHT22,4)
    print(humi)
    print(temp)
    sleep(1)
