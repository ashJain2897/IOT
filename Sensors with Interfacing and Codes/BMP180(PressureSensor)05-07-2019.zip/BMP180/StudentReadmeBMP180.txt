##############################################################################

Project Name:BMP180 (Pressure Sensor) on Arduino and RaspberryPi
Project Date: 05/07/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

Raspberry Pi Connections:

VCC	5v
GND	GND
SDA	board 3
SCL	board 5

Arduino Conmections:

VCC	5v
GND	GND
SCL	A5	
SDA	A4
###############################################################################
Full Information of BMP180

setup:
	
	1)go to path:   BMP180\Pi\Adafruit_Python_BMP\
	Enter command: sudo python setup.py install

	2)now run the code
Links:

Arduino:

	https://randomnerdtutorials.com/guide-for-bmp180-barometric-sensor-with-arduino/

	http://www.circuitbasics.com/set-bmp180-barometric-pressure-sensor-arduino/

Pi:
	https://thepihut.com/blogs/raspberry-pi-tutorials/18025084-sensors-pressure-temperature-and-altitude-with-the-bmp180
	https://tutorials-raspberrypi.com/raspberry-pi-and-i2c-air-pressure-sensor-bmp180/