	##########BMP180###########

Description:
		BMP180 interfacing with raspberry pi
		BMP180 Gives Temperatur,pressure ,altitude and sea level pressure.
Connection:	

Module PCB	Desc	GPIO Header Pins
VCC		3.3V		P1-01
GND		Ground		P1-06
SCL		I2C SCL		P1-05
SDA		I2C SDA		P1-03


Links:
	https://www.raspberrypi-spy.co.uk/2015/04/bmp180-i2c-digital-barometric-pressure-sensor/
	
	Datasheet
	https://cdn-shop.adafruit.com/datasheets/BST-BMP180-DS000-09.pdf
