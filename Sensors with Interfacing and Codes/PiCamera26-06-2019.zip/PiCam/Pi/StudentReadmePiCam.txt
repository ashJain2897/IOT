##############################################################################

Project Name:PiCam on RaspberryPi
Project Date: 26/06/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

Connect 15 pin ribbon cable to CSI inteface on RaspberryPi




###############################################################################
Full Information of PiCam:

Links:

https://projects.raspberrypi.org/en/projects/getting-started-with-picamera



https://uk.pi-supply.com/products/raspberry-pi-camera-board-v1-3-5mp-1080p



https://robu.in/product/raspberry-pi-camera-module/
