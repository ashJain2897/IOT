#####################################################################

Project Name:GPS Sensor on Arduino 
Project Date: 18/06/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

GND : GND
VCC : 5V VCC
TX :   Digital 4 (This pin is mentioned as RXpin in Code because if sensor transmits data            through  TX pin then we should get this data to RXpin(reciever))
RX : Digital 3 (mentioned in code as TXpin)
###############################################################################
Full Information of GPS Sensor with Arduino(Contain diagrams,connections,code):
Important Links:
 
https://en.wikipedia.org/wiki/Global_Positioning_System

https://www.electronicwings.com/sensors-modules/gps-receiver-module 