import time
import serial
import string
import pynmea2
import RPi.GPIO as gpio
import ast
#import webbrowser
#import webrunner
#import mechanize
#from webrunner import webBrowser

#wb = WebBrowser()

raw = ""

#port = "/dev/ttyAMA0" #Serial port to which the pi is connected.
port = "/dev/ttyUSB0"

#create a serial object
ser = serial.Serial(port, baudrate = 9600)

#ser.flush()
#ser.close()
count=0

while 1:
    
    #print("before read")
    data = ser.readline()
    print(data);
    data1=list(data.split(","))
    #data1=list(data1)
    print("GGA(Global Positioning fixed Data) Format ")
    print(data1)
    print('\n###########################################################\n')
    print("Latitude-->\n")
    print(data1[2])
    lat_degree=data1[2]
    lat_degree1=float(lat_degree[0:2])
    lat_degree2=float(lat_degree[2:9])
    lat_degree2/=60
    FinalLat=lat_degree1+lat_degree2
    print(str(FinalLat) + " Decimal Degrees")
    
    print('\n###########################################################\n')    

    print("Longitude-->\n")
    print(data1[4])
    lon_degree=data1[4]
    lon_degree1=float(lon_degree[0:3])
    lon_degree2=float(lon_degree[3:10])
    print(lon_degree2)
    lon_degree2/=60
    FinalLon=lon_degree1+lon_degree2
    print(str(FinalLon)+" Decimal Degrees")

    print('\n###########################################################\n')	
    time.sleep(2)
    #list2=lis(data)
    #print(list2)
    #raw = data.decode('utf-8')
    #list1=list(raw)
    #print(list1)
    #print(list1[2])    
    #print(raw[0:6])
    #print(raw)
    #map_link = 'http://maps.google.com/?q=' + FinalLat + ',' + FinalLon
    #wb.urlopen(map_link)
    '''
    if raw[0:6] == '$GNGGA':    # The longitude and latitude string GNGGA
        #print(raw[0:70])
        msg = pynmea2.parse(raw[0:6])
        #print(msg)
        latlav = msg.latlav #Parsing the latitude           
        #concatlat = "Lat : " + str(longval)
        Lat = ast.literal_eval(latlav)
        print("Lat : " + str(lat))
        longval = msg.lon
        #concatlong = "Long : " + str(longval)
        Long = ast.literal_eval(longval)
        print("Long : " + str(Long))
        #time.sleep(0.5) 
        #ser.flush()
        #ser.close()
        #break
    '''
    count+=1
    if(count==1):
    	break
        

