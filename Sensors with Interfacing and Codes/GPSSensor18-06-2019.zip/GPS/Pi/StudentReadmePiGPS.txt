##############################################################################

Project Name:GPS Sensor on RaspberryPi
Project Date: 18/06/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

PS Sensor(Neo-6M)



Vcc = 3.3

TX  = Rx(USB Tool)

RX  = NC

GND = GND



USB Tool

Vcc = 3.3

RX  = TX(GPS Sensor)

TX  = NC

GND = GND

Vcc(5.5) = NC
###############################################################################
Full Information of GPS Sensor with Pi:
Important Links:
 
https://en.wikipedia.org/wiki/Global_Positioning_System

https://www.electronicwings.com/sensors-modules/gps-receiver-module 