import RPi.GPIO as GPIO
from time import sleep
import sys

#Pins For Motor
motor_channel = (29,31,33,35)

GPIO.setwarnings(False)
#Setting Board Mode i.e above are header pin nos.
GPIO.setmode(GPIO.BOARD)

#Setting Pins As Output Pins
GPIO.setup(motor_channel,GPIO.OUT)

motor_direction = input('Select Motor Direction a = Anticlockwise , c = Clockwise  ')

while True:
    try:
        if(motor_direction == 'c'):
            print("Motor Running ClockWise\n")
            GPIO.output(motor_channel,(GPIO.HIGH,GPIO.LOW,GPIO.LOW,GPIO.HIGH))
            sleep(0.02)
            GPIO.output(motor_channel,(GPIO.HIGH,GPIO.HIGH,GPIO.LOW,GPIO.LOW))
            sleep(0.02)
            GPIO.output(motor_channel,(GPIO.LOW,GPIO.HIGH,GPIO.HIGH,GPIO.LOW))
            sleep(0.02)
            GPIO.output(motor_channel,(GPIO.LOW,GPIO.LOW,GPIO.HIGH,GPIO.HIGH))
            sleep(0.02)
            
        elif(motor_direction == 'a'):
            print("Motor Running AntiClockWise\n")
            GPIO.output(motor_channel,(GPIO.HIGH,GPIO.LOW,GPIO.LOW,GPIO.HIGH))
            sleep(0.02)
            GPIO.output(motor_channel,(GPIO.LOW,GPIO.LOW,GPIO.HIGH,GPIO.HIGH,))
            sleep(0.02)
            GPIO.output(motor_channel,(GPIO.LOW,GPIO.HIGH,GPIO.HIGH,GPIO.LOW))
            sleep(0.02)
            GPIO.output(motor_channel,(GPIO.HIGH,GPIO.HIGH,GPIO.LOW,GPIO.LOW))
            sleep(0.02)
            

    except KeyboardInterrupt:
        motor_direction = input('Select Motor Direction a = Anticlockwise , c = Clockwise, q = Quit ')
        if(motor_direction == 'q'):
            print("Motor Stopped")
            sys.exit(0)
