#######################################################

Project Name - Stepper Motor (28BYJ-48 with UNL2003)
Project Date - June 17, 2019
Author 	     - NXP Semiconductor Leaders
Version      - 1.0v

#######################################################

Arduino

IN1 - 08
IN2 - 09
IN3 - 10
IN4 - 11

VCC - 5V
GND - GND

#######################################################

Raspberry Pi

IN1 - BOARD 29
IN2 - BOARD 31
IN3 - BOARD 33
IN4 - BOARD 35

VCC - 5V
GND - GND

#######################################################
Important Links:

Stepper Motor Working:
https://www.youtube.com/watch?time_continue=40&v=TWMai3oirnM

https://www.elprocus.com/stepper-motor-types-advantages-applications/