##############################################################################

Project Name:LED Matrix on Arduino
Project Date: 27/06/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

 *   DIN - Pin 12
 *   CLK - Pin 11
 *   CS  - Pin 10
 *   VCC - 5V
 


###############################################################################
Full Information of LED Matrix:

Links:

https://howtomechatronics.com/tutorials/arduino/8x8-led-matrix-max7219-tutorial-scrolling-text-android-control-via-bluetooth/

https://www.instructables.com/id/Arduino-8x8-LED-Matrix/
