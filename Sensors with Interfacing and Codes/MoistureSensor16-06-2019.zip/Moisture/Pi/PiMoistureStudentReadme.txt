#####################################################################

Project Name: Moisture Sensor on Arduino And RaspberryPi
Project Date: 17/06/2019
Author: NXP Semiconductors
Version: 1.0v

#####################################################################
Connections(These connections are only for digital output pin without using IC):

VCC : 5V VCC
GND : GND
D0 : 40

For other connections with IC for analog ouput on Pi board,please reffer following links.
#####################################################################
Important links(contain diagrams, codes,Connections):

Raspberry Pi and Moisture Sensor Information Links:
https://www.instructables.com/id/Soil-Moisture-Sensor-Raspberry-Pi/