#####################################################################

Project Name: Moisture Sensor on Arduino And RaspberryPi
Project Date: 17/06/2019
Author: NXP Semiconductors
Version: 1.0v

###############################################################################
Connections:

GND : GND
VCC : 5V VCC
A0 : A0
###############################################################################
Full Information of Moisture Sensor with Arduino(Contain diagrams,connections,code):
Important Links:
 
https://www.electronicwings.com/arduino/soil-moisture-sensor-interfacing-with-arduino-uno 

http://www.circuitstoday.com/arduino-soil-moisture-sensor   