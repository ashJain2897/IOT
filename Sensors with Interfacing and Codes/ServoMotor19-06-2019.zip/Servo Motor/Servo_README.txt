##############################################
Project Name - Servo Motor with Arduino and RaspberryPi
Project Date - 15 June 2019
Author 	     - NXP Semiconductors
Version      - 1.0v
##############################################

Library - Servo.h (In Built)

##############################################
Arduino:

Pinout :      RED	- 5V
	 BROWN	- GND
	 ORANGE	- Digital 9

##############################################
RaspberryPi:

Pinout :      RED	- 5V
	 BROWN	- GND
	 ORANGE	- 40(BOARD)

##############################################
Importanrt Links:
For Arduino:
https://www.electronicwings.com/arduino/servo-motor-interfacing-with-arduino-uno
For RaspberryPi:
https://www.electronicshub.org/raspberry-pi-servo-motor-interface-tutorial/

