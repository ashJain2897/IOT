import RPi.GPIO as GPIO
import time
#GPIO.cleanup()
GPIO.setmode(GPIO.BOARD)#In BCM(Broadcom) mode -> Use GPIO no.
GPIO.setwarnings(False)

GPIO.setup(40,GPIO.OUT)    #In BOARD mode -> Use pin no. 

servo = GPIO.PWM(40, 50)
servo.start(12.5)

try:

    while True:
        
        servo.ChangeDutyCycle(2.5)
        time.sleep(1)

        servo.ChangeDutyCycle(7.5)
        time.sleep(1)

        servo.ChangeDutyCycle(12.5)
        time.sleep(1)

except Exception as e:
    
        print(e)
        servo.stop()

