##############################################################################

Project Name: Pulse Sensor and RTC on Arduino
Project Date: 02/07/2019
Authors: NXP Semiconductors Group Leaders
Version: 1.0v

###############################################################################
Connections:

Pulse Sensor Connections with Arduino:

+ve (Red)	                   VCC (5v)
-ve (Brown)	GND
Data (Green)	A0

RTC Connections with Arduino :

SCL    A5
SDA   A4
VCC   +5V
GND  GND

###############################################################################

Links for Pulse Sensor:

Reffer only working from this site:
http://www.circuitstoday.com/pulse-sensor-arduino

https://pulsesensor.com/pages/code-and-guide

Links for RTC:

https://howtomechatronics.com/tutorials/arduino/arduino-ds3231-real-time-clock-tutorial/

https://www.electronicshub.org/arduino-real-time-clock-tutorial/